package com.jediupc.helloandroid.musicplayer;

public class TicksEvent {
    public long position;
    public long duration;
}
