package com.jediupc.helloandroid.musicplayer;

public class MusicModel {
    public String path;
    public String name;
    public long duration;
}
