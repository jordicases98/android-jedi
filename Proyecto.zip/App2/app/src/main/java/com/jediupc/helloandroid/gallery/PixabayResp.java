package com.jediupc.helloandroid.gallery;

import java.util.ArrayList;

public class PixabayResp {

    public ArrayList<GalleryModel> hits;

}
