package com.jediupc.helloandroid;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class ListEditorActivity extends AppCompatActivity {
    private ArrayList<MenuItem> list = new ArrayList<>() ;
    private RecyclerView mRecyclerView;
    private MyAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_editor);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final LayoutInflater inflater = this.getLayoutInflater();
        mRecyclerView = findViewById(R.id.recyclerView2);
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        FloatingActionButton fab = findViewById(R.id.fab);
        Button change = findViewById(R.id.change);
        final AlertDialog dialogBuilder = new AlertDialog.Builder(this).create();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View dialogView = inflater.inflate(R.layout.custom_dialog, null);
                final EditText editText = ( dialogView.findViewById(R.id.edt_comment));
                Button button1 =  dialogView.findViewById(R.id.buttonSubmit);
                Button button2 =  dialogView.findViewById(R.id.buttonCancel);
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialogBuilder.dismiss();
                    }
                });
                button1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String s = editText.getText().toString();
                        list.add(new MenuItem(s,ListEditorActivity.class));
                        /*SharedPreferences sharedPref = getApplicationContext().getSharedPreferences(
                                "My_preferences", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.putString(s, "string value"); // Storing string
                        editor.apply(); */
                        dialogBuilder.dismiss();
                    }
                });
                dialogBuilder.setView(dialogView);
                dialogBuilder.show();
            }
        });
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        mAdapter = new MyAdapter(list, new MyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int pos) {

            }
        });
        mRecyclerView.setAdapter(mAdapter);



    }

}
